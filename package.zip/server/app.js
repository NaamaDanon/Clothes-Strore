const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');

// ADD THIS LINE:
const loginRouter = require('./routes/login-server');
const registerRouter = require('./routes/register-server');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '..', 'public')));

// ADD THIS LINE:
app.use('/api', loginRouter);
app.use('/api', registerRouter);

// Check login status route
app.get('/api/check-login', (req, res) => {
  try {
    // Assuming you store the logged-in username in a cookie called "username"
    const isLogged = !!(req.cookies && req.cookies.username);
    res.json({ loggedIn: isLogged });
  } catch (err) {
    console.error('Error in /api/check-login:', err);
    res.status(500).json({ loggedIn: false, error: 'Internal server error' });
  }
});

// Temporary test route
app.get('/api/test', (req, res) => {
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
